System.register([], function (exports_1, context_1) {
    "use strict";
    var Merlin;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            Merlin = class Merlin {
                // Declare variables:
                // jQuery Objects:
                constructor() {
                    // Assign variables:
                    // Find & assign jQuery Objects to variables:
                    //    Clippy.load('Merlin', function( agent : Clippy ){
                    //        // do anything with the loaded agent
                    //        agent.show();
                    //    });
                    // if (this.debug) {
                    // 	console.log('Merlin ready');
                    // }
                }
            };
            exports_1("Merlin", Merlin);
        }
    };
});

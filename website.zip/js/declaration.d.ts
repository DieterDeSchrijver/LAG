declare module "youtubeIframeAPI" {
	export = YT;
}
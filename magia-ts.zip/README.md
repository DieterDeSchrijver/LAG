# magia-ts
A responsive single page HTML5 website with scripts written in TypeScript.

## Install
Compiled files are already in the respository.

Do the following in order to recompile from within project directory.
Get required NPM modules:
`npm install`

To compile SASS & TypeScript:
`./node_modules/.bin/gulp`